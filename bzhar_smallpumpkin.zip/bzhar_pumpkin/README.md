# bzhar_pumpkin

Giant Halloween pumpkin prop for RedM

## Features

- 5.45 x 4.67 x 3.33 m, origin at the bottom center so it sits flat on the ground
- 2048 PBR textures (color, normal, material) embedded in the model
- 500 triangle collision, players, horses and wagons can't pass through it
- 60 m draw distance

## Requirements

- RedM server

## Installation

1. Put the `bzhar_pumpkin` folder in your `resources` folder
2. Add `ensure bzhar_pumpkin` to your `server.cfg`
3. Restart the server

## Usage

Model name: `bzhar_pumpkin`

Spawn it with any object placement tool, or from your own script:

```lua
local model = joaat('bzhar_pumpkin')
RequestModel(model)
while not HasModelLoaded(model) do Wait(0) end
local pumpkin = CreateObject(model, x, y, z, true, true, false)
SetModelAsNoLongerNeeded(model)
```
