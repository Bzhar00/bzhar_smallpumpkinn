fx_version 'cerulean'
game 'rdr3'
rdr3_warning 'I acknowledge that this is a prerelease build of RedM, and I am aware my resources *will* become incompatible once RedM ships.'

author 'bzhar'
description 'Giant Halloween pumpkin prop with collision'
version '1.0.0'

this_is_a_map 'yes'

files {
    'stream/bzhar_pumpkin.ytyp'
}

data_file 'DLC_ITYP_REQUEST' 'stream/bzhar_pumpkin.ytyp'
