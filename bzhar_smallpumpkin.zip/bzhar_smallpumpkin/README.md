# bzhar_pumpkin

Small Halloween pumpkin prop made to sit on a player's shoulder

## Features

- 25 x 21 x 15 cm, origin at the bottom center so it sits on top of the bone you attach it to
- 1024 PBR textures (color, normal, material) embedded in the model
- No collision, it never pushes the player or blocks other players
- 60 m draw distance

## Requirements

- RedM server

## Installation

1. Put the `bzhar_pumpkin` folder in your `resources` folder
2. Add `ensure bzhar_pumpkin` to your `server.cfg`
3. Restart the server

## Usage

Model name: `bzhar_pumpkin`

Attach it with any wearable prop tool, or from your own script:

```lua
local ped = PlayerPedId()
local model = joaat('bzhar_pumpkin')
RequestModel(model)
while not HasModelLoaded(model) do Wait(0) end
local pumpkin = CreateObject(model, 0.0, 0.0, 0.0, true, true, true)
local bone = GetEntityBoneIndexByName(ped, 'SKEL_R_UpperArm')
AttachEntityToEntity(pumpkin, ped, bone, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, true, true, false, true, 1, true)
SetModelAsNoLongerNeeded(model)
```

Tune the offset and rotation values until it sits where you want it on the shoulder
